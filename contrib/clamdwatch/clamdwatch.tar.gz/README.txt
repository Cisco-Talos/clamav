clamdwatch.pl:

Clamdwatch is made to be ran from (ana)cron to check the status of the
clamd daemon.  The script contains a copy of the EICAR test virus
signature.  Clamdwatch connects to the clamd socket and asks clamd to
scan it (the script).  If, within 15 seconds (default timeout), clamd
returns claiming it found the virus, the script returns 1.  If clamd
takes longer than the timeout to respond (or doesn't finde the virus
test signature) the script returns 0.  It also returns 0 if the socket
(defined as $Socket) is not present or if it can't connect to the
socket.

Please send any suggestions/comments/patches to
clamdwatch-NOSPAM@mikecathey.com (remove "-NOSPAM").

Enjoy!
